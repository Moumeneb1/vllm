"""Run paired fresh-process measurements without changing the loaded model."""

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, help="Pinned local snapshot directory")
    parser.add_argument("--source", required=True, type=Path, help="Patched vLLM checkout")
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument("--config", type=Path, default=Path("benchmark.json"))
    parser.add_argument("--sync-check-only", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    stage = root / "runtime"
    results = root / "results"
    stage.mkdir(exist_ok=True)
    results.mkdir(exist_ok=True)
    environment = dict(os.environ)
    environment.update(
        PYTHONPATH=str(args.source.resolve()) + os.pathsep + str(root),
        VOXTRAL_LOCAL_SOURCE=str(args.source.resolve()),
        VOXTRAL_NORMALIZER_ROOT=str(root),
        OMP_NUM_THREADS="1",
        VLLM_USE_RUST_FRONTEND="0",
        TOKENIZERS_PARALLELISM="false",
    )
    config = json.loads((root / args.config).read_text())
    for round_number in range(1 if args.sync_check_only else args.rounds):
        current = dict(config)
        current["cases"] = [x for x in config["cases"] if x["repeat"] == round_number]
        modes = ("native", "graphs") if round_number % 2 == 0 else ("graphs", "native")
        if args.sync_check_only:
            current["cases"] = [x for x in current["cases"] if x["mode"] == "graphs" and x["concurrency"] == 8][:1]
            modes = ("graphs",)
            environment["VLLM_GPU_SYNC_CHECK"] = "error"
        config_path = results / f"round_{round_number}.json"
        config_path.write_text(json.dumps(current, indent=2) + "\n")
        for mode in modes:
            label = "sync_guard" if args.sync_check_only else f"{mode}_{round_number}"
            subprocess.run(
                [sys.executable, str(root / "serving.py"), "--model", args.model,
                 "--root", str(root), "--stage", str(stage), "--config", str(config_path),
                 "--mode", mode, "--output", str(results / f"{label}.json")],
                env=environment,
                check=True,
            )


if __name__ == "__main__":
    main()
