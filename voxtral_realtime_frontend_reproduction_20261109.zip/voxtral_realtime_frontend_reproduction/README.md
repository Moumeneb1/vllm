# Voxtral Realtime frontend graph reproduction

These scripts use public audio, the original BF16 checkpoint, and the public
Realtime WebSocket endpoint. They add no model hook or request-time capture.
The optimization is selected at server startup with `cudagraph_mm_encoder`.

Use a CUDA vLLM environment built at the tested revision. The source manifest
checks the changed files before each server starts. `production.patch` applies
to base `dce91fea6b13c99b8fa91d9f58673e7123c6dc65`.

```bash
git checkout dce91fea6b13c99b8fa91d9f58673e7123c6dc65
git apply /path/to/reproduction/production.patch
VLLM_USE_PRECOMPILED=1 \
VLLM_PRECOMPILED_WHEEL_VARIANT=cu130 \
VLLM_PRECOMPILED_WHEEL_COMMIT=827f2ccfafd92757955a8c8a9c3600b99e18734c \
uv pip install -e . --torch-backend=auto
uv pip install soundfile pyarrow requests websockets rapidfuzz
```

The measured runtime used Python 3.12.13, Torch 2.14.0+cu130,
Transformers 5.22.0, FlashInfer 0.7.3 and Humming 0.1.19 on an A100 80 GB.
Keep those versions when comparing with the supplied results.
Each GPU allocation had 16 CPU cores assigned; model CPU operations used
`OMP_NUM_THREADS=1` as set below.

Prepare the hash-checked 16 kHz mono PCM16 WAV files. Parquet sources and
revisions are pinned in `audio_manifest.json`; WAV hashes are checked after
reconstruction. Audio includes short, medium and long utterances from the
Earnings22 subset and full/cropped TEDLIUM recordings. Crops without aligned
transcripts are excluded from WER. No source WAVs or model weights are bundled.

```bash
cd /path/to/reproduction
/path/to/vllm/.venv/bin/python prepare_audio.py
export PYTHONPATH=/path/to/vllm:$PWD
export VOXTRAL_LOCAL_SOURCE=/path/to/vllm
export VOXTRAL_NORMALIZER_ROOT=$PWD
export OMP_NUM_THREADS=1
export VLLM_USE_RUST_FRONTEND=0 TOKENIZERS_PARALLELISM=false
mkdir -p runtime results
```

For each round 0–3, select cases whose `repeat` equals the round in
`benchmark.json`. Start separate native and graph servers, using native/graphs
order for rounds 0 and 2, and graphs/native order for rounds 1 and 3:

```bash
/path/to/vllm/.venv/bin/python run_matrix.py \
  --source /path/to/vllm --model /path/to/pinned/model/snapshot
```

The runner performs that selection and ordering automatically. A single
server measurement can also be invoked directly with a per-round config:

```bash
/path/to/vllm/.venv/bin/python serving.py \
  --model mistralai/Voxtral-Mini-4B-Realtime-2602 \
  --root "$PWD" --stage "$PWD/runtime" \
  --config round_0.json --mode native --output results/native_0.json
# Run the same command with --mode graphs and results/graphs_0.json.
```

`serving.py` launches and shuts down a fresh server for each invocation. Both
modes retain full encoder/decoder decode graphs, max_num_seqs=64,
max_model_len=16384, gpu_memory_utilization=0.75, and the same packet size and
request lists. Eighty-millisecond PCM packets are uploaded faster than real
time for capacity measurements; cases marked `paced` test live arrival.

Use the official model revision
`2769294da9567371363522aac9bbcfdd19447add`. For immutable offline testing,
download that snapshot first and pass its local directory as `--model`.
The weights SHA256 is
`263f178fe752c90a2ae58f037a95ed092db8b14768b0978b8c48f66979c8345d`.

Results contain every transcript and request latency, normalized WER,
frontend graph-hit statistics, startup duration, allocated/reserved/peak
Torch memory, driver free memory, available KV bytes and allocated KV blocks.
The `kv_allocated_bytes` field reports the extensible cache's physically
committed bytes. Its much larger virtual tensor reservation is a separate
field and must not be treated as GPU memory consumption.
Compare matching pairs, report the geometric mean and range over four rounds,
and report memory ranges across separate starts. Run a separate untimed graph
case with `VLLM_GPU_SYNC_CHECK=error`.

For the three-pair, 32-stream live-arrival supplement, use a separate results
directory so the main sweep is retained:

```bash
mv results capacity_results
/path/to/vllm/.venv/bin/python run_matrix.py \
  --source /path/to/vllm --model /path/to/pinned/model/snapshot \
  --config live_supplement.json --rounds 3
```

Correctness tests in the patched repository:

```bash
.venv/bin/python -m pytest tests/v1/cudagraph/test_encoder_cudagraph.py -v
.venv/bin/python -m pytest \
  tests/models/multimodal/generation/test_voxtral_realtime.py -m core_model -v
```

The supplied spelling-normalization dictionary is the public Whisper English
normalizer used for both modes. `audio_manifest.json` records the original
dataset repositories, immutable revisions, references and crop boundaries.

The tested source is PR commit `2195f1c7e5871275b9a7add601944ab41ad653d1`.
The official native wheel is from upstream parent `827f2ccfafd92757955a8c8a9c3600b99e18734c`; all compiled inputs match the source base, including custom-op wrappers.
